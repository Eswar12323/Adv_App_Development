package com.jwt.jwt.entity;

public enum Role {
    USER,
    ADMIN
}
